﻿using System;
using System.Collections.Generic;
using System.Text;

namespace oop_6115261025_w02
{
    class Section
    {
        private string sectionCode;
        private string sectionName;
        private string sectionBuilding;
        private string sectionSubject;
        private string sectionLecturer;
        private string sectionDay;
        private string sectionStarTime;
        private string sectionLastTime;

        public string SectionCode
        {
            get { return sectionCode; }
            set { sectionCode = value; }
        }
        public string SectionName
        {
            get { return sectionName; }
            set { sectionName = value; }
        }
        public string SectionBuilding
        {
            get { return sectionBuilding; }
            set { sectionBuilding = value; }
        }
        public string SectionSubject
        {
            get { return sectionSubject; }
            set { sectionSubject = value; }
        }
        public string SectionLecturer
        {
            get { return sectionLecturer; }
            set { sectionLecturer = value; }
        }
        public string SectionDay
        {
            get { return sectionDay; }
            set { sectionDay = value; }
        }
        public string SectionStarTime
        {
            get { return sectionStarTime; }
            set { sectionStarTime = value; }
        }
        public string SectionLastTime
        {
            get { return sectionLastTime; }
            set { sectionLastTime = value; }
        }
        public Section() { }

        public Section(string sc, string sn, string sb, string ss,string sl,string sd,string sst,string slt)
        {
            this.sectionCode = sc;
            this.sectionName = sn;
            this.sectionBuilding = sb;
            this.sectionSubject = ss;
            this.sectionLecturer = sl;
            this.sectionDay = sd;
            this.sectionStarTime = sst;
            this.sectionLastTime = slt;
        }

        public override string ToString()
        {
            return this.sectionCode +
                   this.sectionName +
                   this.sectionBuilding +
                   this.sectionSubject +
                   this.sectionLecturer +
                   this.sectionDay +
                   this.sectionStarTime +
                   this.sectionLastTime ;
        }
    }
}
