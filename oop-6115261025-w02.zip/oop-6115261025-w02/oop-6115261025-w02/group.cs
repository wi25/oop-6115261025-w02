﻿using System;
using System.Collections.Generic;
using System.Text;

namespace oop_6115261025_w02
{
    class group
    {
        private string groupCode;
        private string groupName;
        private string groupDegree;
        
        public string GroupCode
        {
            get { return groupCode; }
            set { groupCode = value; }
        }
        public string GroupName
        {
            get { return groupName; }
            set { groupName = value; }
        }
        public string GroupDegree
        {
            get { return groupDegree; }
            set { groupDegree = value; }
        }
        public group() { }
               group(string gc, string gn, string gd)
        {
            this.groupCode = gc;
            this.groupName = gn;
            this.groupDegree = gd;
        }

        public override string ToString()
        {
            return this.GroupCode +
                   this.GroupName +
                   this.GroupDegree;
        }
    }

}
